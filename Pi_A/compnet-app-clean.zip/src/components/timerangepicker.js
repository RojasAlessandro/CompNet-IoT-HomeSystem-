import React from 'react';

export default function TimeRangePicker({
  startHour,
  startMin,
  startPeriod,
  endHour,
  endMin,
  endPeriod,
  setStartHour,
  setStartMin,
  setStartPeriod,
  setEndHour,
  setEndMin,
  setEndPeriod
}) {
  return (
    <div className="space-y-4">
      {[
        ['Start', startHour, setStartHour, startMin, setStartMin, startPeriod, setStartPeriod],
        ['End', endHour, setEndHour, endMin, setEndMin, endPeriod, setEndPeriod],
      ].map(([label, hour, setHour, min, setMin, period, setPeriod]) => (
        <div key={label} className="flex items-center justify-between">
          <label className="text-sm font-medium w-1/4">{label}</label>
          <div className="flex items-center gap-2">
            <input
              type="number"
              min="1"
              max="12"
              value={hour}
              onChange={(e) => setHour(e.target.value)}
              className="border border-gray-300 px-4 py-2 rounded w-20 text-center"
            />
            <span>:</span>
            <input
              type="number"
              min="0"
              max="59"
              value={min}
              onChange={(e) => setMin(e.target.value)}
              className="border border-gray-300 px-4 py-2 rounded w-20 text-center"
            />
            <select
              value={period}
              onChange={(e) => setPeriod(e.target.value)}
              className="border border-gray-300 px-4 py-2 rounded"
            >
              <option>AM</option>
              <option>PM</option>
            </select>
          </div>
        </div>
      ))}
    </div>
  );
}
