import React, { useState, useEffect } from 'react';
import { Lightbulb } from 'lucide-react';
import TimeRangePicker from './timerangepicker';
import client from '../mqttService';

export default function LightControl() {
  const [toggles, setToggles] = useState({
    light: true,
    autolight: true,
    setlight: true,
  });

  const [startHour, setStartHour] = useState('3');
  const [startMin, setStartMin] = useState('00');
  const [startPeriod, setStartPeriod] = useState('PM');

  const [endHour, setEndHour] = useState('4');
  const [endMin, setEndMin] = useState('00');
  const [endPeriod, setEndPeriod] = useState('PM');

  useEffect(() => {
    if (!toggles.setlight) return;

    const now = new Date();

    const getTime = (hourStr, minStr, period) => {
      let hour = parseInt(hourStr);
      const min = parseInt(minStr);
      if (period === 'PM' && hour !== 12) hour += 12;
      if (period === 'AM' && hour === 12) hour = 0;
      const time = new Date();
      time.setHours(hour, min, 0, 0);
      if (time < now) time.setDate(time.getDate() + 1);
      return time;
    };

    const startTime = getTime(startHour, startMin, startPeriod);
    const endTime = getTime(endHour, endMin, endPeriod);

    const msUntilStart = startTime.getTime() - now.getTime();
    const msUntilEnd = endTime.getTime() - now.getTime();

    let startTimer = setTimeout(() => {
      client.publish('iot/led_b/control', 'on');
      client.publish('home/light', 'ON');
    }, msUntilStart);

    let endTimer = setTimeout(() => {
      client.publish('iot/led_b/control', 'off');
      client.publish('home/light', 'OFF');
    }, msUntilEnd);

    console.log(`Light will turn ON at ${startTime.toLocaleTimeString()} and OFF at ${endTime.toLocaleTimeString()}`);

    return () => {
      clearTimeout(startTimer);
      clearTimeout(endTimer);
    };
  }, [startHour, startMin, startPeriod, endHour, endMin, endPeriod, toggles.setlight]);

  const toggleSwitch = (key) => {
    const newValue = !toggles[key];
    setToggles((prev) => ({ ...prev, [key]: newValue }));

    if (key === 'light') {
      const controlMsg = newValue ? 'on' : 'off';
      const statusMsg = newValue ? 'ON' : 'OFF';
      client.publish('iot/led_b/control', controlMsg);
      client.publish('home/light', statusMsg);
    }
  };

  return (
    <>
      <div className="flex items-center gap-3 mb-6">
        <Lightbulb size={32} />
        <h2 className="text-2xl font-bold">Light</h2>
      </div>

      <div className="space-y-4 mb-6">
        {[['Light', 'light'], ['Set Light', 'setlight']].map(([label, key]) => (
          <div key={key} className="flex justify-between items-center">
            <span className="text-sm font-medium">{label}</span>
            <button
              onClick={() => toggleSwitch(key)}
              className={`w-10 h-6 rounded-full flex items-center px-1 transition ${
                toggles[key] ? 'bg-black' : 'bg-gray-300'
              }`}
            >
              <div
                className={`w-4 h-4 bg-white rounded-full shadow transition-transform ${
                  toggles[key] ? 'translate-x-5' : ''
                }`}
              />
            </button>
          </div>
        ))}
      </div>

      {toggles.setlight && (
        <div className="mt-6">
          <hr className="mb-6" />
          <TimeRangePicker
            startHour={startHour}
            setStartHour={setStartHour}
            startMin={startMin}
            setStartMin={setStartMin}
            startPeriod={startPeriod}
            setStartPeriod={setStartPeriod}
            endHour={endHour}
            setEndHour={setEndHour}
            endMin={endMin}
            setEndMin={setEndMin}
            endPeriod={endPeriod}
            setEndPeriod={setEndPeriod}
          />
        </div>
      )}
    </>
  );
}
