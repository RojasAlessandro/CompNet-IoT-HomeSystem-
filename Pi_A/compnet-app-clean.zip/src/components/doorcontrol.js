import React, { useState, useEffect } from 'react';
import { DoorClosedIcon } from 'lucide-react';
import client from '../mqttService';

export default function DoorControl() {
  const [doorOpen, setDoorOpen] = useState(false);
  const [doorbellRinging, setDoorbellRinging] = useState(false);

  useEffect(() => {
    const handleMessage = (topic, message) => {
      const msg = message.toString();
      if (topic === 'iot/led/status') {
        setDoorbellRinging(msg === 'ON');
      }
    };

    client.on('message', handleMessage);
    client.subscribe('iot/led/status');

    return () => {
      client.off('message', handleMessage);
      client.unsubscribe('iot/led/status');
    };
  }, []);

  const toggleDoor = () => {
    const newState = !doorOpen;
    setDoorOpen(newState);
    client.publish('iot/door/control', newState ? 'open' : 'close');
  };

  return (
    <>
      <div className="flex items-center gap-3 mb-6">
        <DoorClosedIcon size={32} />
        <h2 className="text-2xl font-bold">Door</h2>
      </div>

      <div className="flex justify-between items-center mb-6">
        <span className="text-sm font-medium">Door</span>
        <div className="flex items-center gap-3">
          <span className="text-sm font-semibold">
            {doorOpen ? 'Open' : 'Closed'}
          </span>
          <button
            onClick={toggleDoor}
            className={`relative w-12 h-6 rounded-full transition-colors duration-300 ${
              doorOpen ? 'bg-black' : 'bg-gray-300'
            }`}
          >
            <div
              className={`absolute left-1 top-1 w-4 h-4 bg-white rounded-full shadow transition-transform duration-300 ${
                doorOpen ? 'translate-x-6' : ''
              }`}
            />
          </button>
        </div>
      </div>

      <div className="flex justify-between items-center mb-4">
        <span className="text-sm font-medium">Door Bell</span>
        <span className="text-base font-bold">
          {doorbellRinging ? 'RINGING' : 'SILENT'}
        </span>
      </div>

      <div className="mt-6">
        <h3 className="text-lg font-semibold mb-2">Live Camera Feed</h3>
        <div className="border border-black p-2 w-full max-w-md">
          <img
            src="http://192.168.198.61:8000/video_feed"
            alt="Camera feed not available"
            className="w-full"
          />
        </div>
      </div>
    </>
  );
}
