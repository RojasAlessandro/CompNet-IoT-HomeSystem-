import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Menu, LogOut, Lightbulb, DoorClosedIcon } from 'lucide-react';
import LightControl from '../components/lightcontrol';
import DoorControl from '../components/doorcontrol';
import client from '../mqttService';

export default function Dashboard() {
  const navigate = useNavigate();
  const [lightOn, setLightOn] = useState(false);
  const [doorbellRinging, setDoorbellRinging] = useState(false);
  const [greeting, setGreeting] = useState('');
  const [bgGradient, setBgGradient] = useState('');
  const [sensorData, setSensorData] = useState({ temperature: '-', humidity: '-' });

  useEffect(() => {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) {
      setGreeting('Good Morning');
      setBgGradient('from-blue-300 via-yellow-200 to-yellow-100');
    } else if (hour >= 12 && hour < 18) {
      setGreeting('Good Afternoon');
      setBgGradient('from-red-400 via-orange-300 to-yellow-300');
    } else {
      setGreeting('Good Evening');
      setBgGradient('from-blue-900 via-purple-700 to-purple-500');
    }
  }, []);

  useEffect(() => {
    const handleMessage = (topic, message) => {
      const msg = message.toString();

      if (topic === 'home/light') {
        setLightOn(msg === 'ON');
      }

      if (topic === 'iot/led/status') {
        setDoorbellRinging(msg === 'ON');
      }

      if (topic === 'iot/dht11/status') {
        try {
          const payload = JSON.parse(msg);
          setSensorData({
            temperature: payload.temperature,
            humidity: payload.humidity,
          });

          // Auto-light logic based on temperature
          if (payload.temperature <= 24) {
            setLightOn(true);
          } else {
            setLightOn(false);
          }
        } catch (err) {
          console.error('Failed to parse sensor data:', err);
        }
      }
    };

    client.on('message', handleMessage);
    client.subscribe('home/light');
    client.subscribe('iot/led/status');
    client.subscribe('iot/dht11/status');

    return () => {
      client.off('message', handleMessage);
      client.unsubscribe('home/light');
      client.unsubscribe('iot/led/status');
      client.unsubscribe('iot/dht11/status');
    };
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 transition-all duration-300 overflow-x-hidden">
      <div className="relative flex items-center justify-center p-4">
        <h1 className="text-lg font-semibold text-center">MySmartHome</h1>
      </div>

      <div className={`bg-gradient-to-r ${bgGradient} px-6 py-10 flex flex-col justify-center rounded-xl m-4 min-h-[40vh]`}>
        <h1 className={`text-4xl sm:text-5xl md:text-6xl font-bold mb-2 ${greeting === 'Good Evening' ? 'text-white' : 'text-black'}`}>
          {greeting}
        </h1>
        <p className={`text-base sm:text-lg md:text-xl ${greeting === 'Good Evening' ? 'text-white' : 'text-black'}`}>
          Current room temperature is {sensorData.temperature} °C and humidity is {sensorData.humidity} %
        </p>
      </div>

      <div className="flex-1 bg-white px-6 py-8 m-4 rounded-xl shadow-md flex flex-col justify-center min-h-[30vh]">
        <h3 className="text-center text-lg sm:text-xl md:text-2xl font-semibold mb-6 text-black">
          Smart Devices
        </h3>

        <div className="flex flex-col md:flex-row justify-center items-center gap-6">
          {/* Light Card */}
          <div className="bg-white border border-gray-300 rounded-3xl p-6 w-full max-w-xs flex justify-between items-center shadow-md">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-gray-100 rounded-full">
                <Lightbulb size={20} className="text-gray-600" />
              </div>
              <span className="text-lg text-black font-medium">Light</span>
            </div>
            <span className="text-lg font-semibold text-black">{lightOn ? 'ON' : 'OFF'}</span>
          </div>

          {/* Door Bell Card */}
          <div className="bg-white border border-gray-300 rounded-3xl p-6 w-full max-w-xs flex justify-between items-center shadow-md">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-gray-100 rounded-full">
                <DoorClosedIcon size={20} className="text-gray-600" />
              </div>
              <span className="text-lg text-black font-medium">Door Bell</span>
            </div>
            <span className="text-lg font-semibold text-black">{doorbellRinging ? 'RINGING' : 'SILENT'}</span>
          </div>
        </div>
      </div>

      <div className="w-full max-w-[1440px] mx-auto flex flex-wrap justify-between gap-6 px-6 mb-10">
        <div className="w-full lg:w-[48.5%] bg-white p-6 sm:p-8 rounded-xl shadow-md min-h-[300px]">
          <LightControl />
        </div>
        <div className="w-full lg:w-[48.5%] bg-white p-6 sm:p-8 rounded-xl shadow-md min-h-[300px]">
          <DoorControl />
        </div>
      </div>
    </div>
  );
}
