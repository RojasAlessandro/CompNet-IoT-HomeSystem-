import mqtt from 'mqtt';

const brokerUrl = 'ws://192.168.198.35:9001'; // must be a WebSocket broker!

const options = {
  clientId: 'ReactDashboard_' + Math.random().toString(16).substr(2, 8),
  keepalive: 60,
  reconnectPeriod: 1000,
  connectTimeout: 30 * 1000,
};

const client = mqtt.connect(brokerUrl, options);

client.on('connect', () => {
  console.log('Connected to MQTT Broker on port 5050');
  client.subscribe('home/light');
  client.subscribe('iot/led/status');
  client.subscribe('iot/dht11/status');
});

client.on('error', (err) => {
  console.error('MQTT Connection Error:', err.message);
  client.end();
});

export default client;
